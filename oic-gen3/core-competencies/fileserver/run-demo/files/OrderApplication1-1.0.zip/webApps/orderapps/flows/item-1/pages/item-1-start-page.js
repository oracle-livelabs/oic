define(['ojs/ojpagingdataproviderview','ojs/ojarraydataprovider'], 
function(PagingDataProviderView,ArrayDataProvider) {
  'use strict';

  
  var PageModule = function PageModule() {};

// Search
    PageModule.prototype.pagingSearchOrder = function(array) {
      var data = new PagingDataProviderView(new ArrayDataProvider(
      array, {
        idAttribute: 'order_id'
        }));
      return data;
    };


  return PageModule;
});
